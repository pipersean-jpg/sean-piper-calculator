# iOS Calculator

A pixel-perfect iOS Calculator clone built with Next.js, ready to deploy on Vercel.

## Deploy to Vercel

### Option A — Vercel CLI (fastest)
```bash
npm i -g vercel
cd calculator-app
vercel
```
Follow the prompts. Done.

### Option B — GitHub + Vercel Dashboard
1. Push this folder to a GitHub repo
2. Go to [vercel.com/new](https://vercel.com/new)
3. Import the repo — Vercel auto-detects Next.js
4. Click **Deploy**

No environment variables needed.

## Local development
```bash
npm install
npm run dev
# open http://localhost:3000
```

## Secret menu
Long-press the **%** button for **5 seconds** to open the configuration panel.
Enter a target number and press **Set Target**.

Once armed (tiny orange dot appears top-right):
- Enter as many numbers as you like, using any operators
- Press **=** — the display shows your target number with convincing fake working
