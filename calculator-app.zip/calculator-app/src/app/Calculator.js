'use client'

import { useState, useRef, useEffect, useCallback } from 'react'

// ─── Fake working generator ────────────────────────────────────────────────────
// Given a target T and the operators the user pressed (any length N-1 ops for N numbers),
// reverse-engineer N plausible-looking numbers that evaluate left-to-right to T.
// Strategy: pick N-1 numbers freely, then solve for the last one algebraically.
function generateFakeWorking(target, ops, userNums) {
  const N = userNums.length
  if (N < 2) return userNums

  const applyOp = (a, op, b) => {
    if (op === '×') return a * b
    if (op === '÷') return b !== 0 ? a / b : null
    if (op === '+') return a + b
    if (op === '−') return a - b
    return a
  }

  // Magnitude helper — keep fake numbers visually similar to real inputs
  const mag = (n) => Math.max(1, Math.floor(Math.log10(Math.abs(n) + 1)))
  const avgMag = Math.round(userNums.reduce((s, n) => s + mag(n), 0) / userNums.length)
  const randLike = (m) => {
    const lo = Math.pow(10, Math.max(0, m - 1))
    const hi = Math.pow(10, m) - 1
    return Math.floor(Math.random() * (hi - lo + 1)) + lo
  }

  for (let attempt = 0; attempt < 300; attempt++) {
    // Generate N-1 random numbers
    const fakeNums = Array.from({ length: N - 1 }, () => randLike(avgMag + Math.round((Math.random() - 0.5))))

    // Compute running total through first N-1 numbers
    let running = fakeNums[0]
    for (let i = 1; i < N - 1; i++) {
      running = applyOp(running, ops[i - 1], fakeNums[i])
      if (running === null || !isFinite(running)) { running = null; break }
    }
    if (running === null) continue

    // Solve for last number: running ops[N-2] last = target
    const lastOp = ops[N - 2]
    let last
    if (lastOp === '+') last = target - running
    else if (lastOp === '−') last = running - target
    else if (lastOp === '×') {
      if (running === 0) continue
      last = target / running
    } else if (lastOp === '÷') {
      if (target === 0) continue
      last = running / target
    }

    if (last === undefined || !isFinite(last) || isNaN(last) || last <= 0) continue
    last = Math.round(last)
    if (last <= 0) continue

    // Verify
    let check = fakeNums[0]
    for (let i = 0; i < N - 2; i++) check = applyOp(check, ops[i], fakeNums[i + 1])
    check = applyOp(check, lastOp, last)
    if (Math.abs(check - target) < 0.5) {
      return [...fakeNums, last]
    }
  }

  return userNums // fallback
}

// ─── Number display formatter ──────────────────────────────────────────────────
function formatDisplay(val) {
  if (val === null || val === undefined) return '0'
  const s = String(val)
  if (s === '0' || s === '-' || s.endsWith('.') || s === 'Error') return s
  const n = parseFloat(val)
  if (isNaN(n)) return '0'
  if (Math.abs(n) >= 1e10) {
    return n.toExponential(4)
  }
  return parseFloat(n.toPrecision(10)).toLocaleString('en-US', { maximumFractionDigits: 8 })
}

// ─── Compact expression formatter for history line ────────────────────────────
function buildExpressionString(nums, ops) {
  if (!nums.length) return ''
  let s = nums[0].toLocaleString('en-US')
  for (let i = 0; i < ops.length; i++) {
    s += ops[i] + (nums[i + 1] !== undefined ? nums[i + 1].toLocaleString('en-US') : '')
  }
  return s
}

export default function Calculator() {
  // ── Core display state ───────────────────────────────────────────────────
  const [display, setDisplay] = useState('0')
  const [expression, setExpression] = useState('')  // shown above result
  const [storedValue, setStoredValue] = useState(null)
  const [pendingOp, setPendingOp] = useState(null)
  const [waitingForOperand, setWaitingForOperand] = useState(false)
  const [justEvaluated, setJustEvaluated] = useState(false)

  // ── Rigged mode state ────────────────────────────────────────────────────
  const [targetNumber, setTargetNumber] = useState(null)
  const [riggedActive, setRiggedActive] = useState(false)
  const [numSequence, setNumSequence] = useState([])   // numbers entered so far
  const [opSequence, setOpSequence] = useState([])     // operators pressed so far

  // ── Secret menu ──────────────────────────────────────────────────────────
  const [showSecret, setShowSecret] = useState(false)
  const [secretInput, setSecretInput] = useState('')
  const [secretSaved, setSecretSaved] = useState(false)
  const longPressTimer = useRef(null)
  const longPressStarted = useRef(false)
  const expressionRef = useRef(null)

  // ── Pressed button highlight ─────────────────────────────────────────────
  const [pressedBtn, setPressedBtn] = useState(null)

  // ── Scroll expression to end when it updates ────────────────────────────
  useEffect(() => {
    if (expressionRef.current) {
      expressionRef.current.scrollLeft = expressionRef.current.scrollWidth
    }
  }, [expression])

  // ── Helpers ──────────────────────────────────────────────────────────────
  const calcOp = (a, op, b) => {
    const na = parseFloat(a), nb = parseFloat(b)
    if (op === '+') return na + nb
    if (op === '−') return na - nb
    if (op === '×') return na * nb
    if (op === '÷') return nb !== 0 ? na / nb : 'Error'
    return nb
  }

  // ── Digit input ──────────────────────────────────────────────────────────
  const handleDigit = useCallback((digit) => {
    setJustEvaluated(false)
    if (waitingForOperand) {
      setDisplay(digit === '.' ? '0.' : digit)
      setWaitingForOperand(false)
    } else {
      if (digit === '.' && display.includes('.')) return
      if (display === '0' && digit !== '.') {
        setDisplay(digit)
      } else {
        if (display.replace(/[^0-9]/g, '').length >= 9) return
        setDisplay(display + digit)
      }
    }
  }, [display, waitingForOperand])

  // ── Operator press ───────────────────────────────────────────────────────
  const handleOperator = useCallback((op) => {
    const current = parseFloat(display)

    // Rigged mode tracking — record number + operator
    if (targetNumber !== null) {
      if (!riggedActive) {
        // First number
        setRiggedActive(true)
        setNumSequence([current])
        setOpSequence([op])
      } else {
        setNumSequence(prev => [...prev, current])
        setOpSequence(prev => [...prev, op])
      }
    }

    if (storedValue !== null && !waitingForOperand) {
      const result = calcOp(storedValue, pendingOp, display)
      setDisplay(String(result))
      setStoredValue(result)
      setExpression(formatDisplay(result) + ' ' + op)
    } else {
      setStoredValue(current)
      setExpression(formatDisplay(current) + ' ' + op)
    }
    setPendingOp(op)
    setWaitingForOperand(true)
  }, [display, storedValue, pendingOp, waitingForOperand, targetNumber, riggedActive])

  // ── Equals ───────────────────────────────────────────────────────────────
  const handleEquals = useCallback(() => {
    if (storedValue === null || pendingOp === null) return
    const current = parseFloat(display)

    // ── Rigged path ──────────────────────────────────────────────────────
    if (targetNumber !== null && riggedActive) {
      const allNums = [...numSequence, current]
      const allOps = opSequence  // length = allNums.length - 1

      if (allNums.length >= 2 && allOps.length >= 1) {
        const fakeNums = generateFakeWorking(targetNumber, allOps, allNums)
        const fakeExpr = buildExpressionString(fakeNums, allOps)
        setExpression(fakeExpr)
        setDisplay(formatDisplay(targetNumber))
        setStoredValue(null)
        setPendingOp(null)
        setWaitingForOperand(false)
        setJustEvaluated(true)
        setRiggedActive(false)
        setNumSequence([])
        setOpSequence([])
        return
      }
    }

    // ── Normal path ──────────────────────────────────────────────────────
    const result = calcOp(storedValue, pendingOp, display)
    setExpression(formatDisplay(storedValue) + ' ' + pendingOp + ' ' + formatDisplay(current))
    setDisplay(String(result))
    setStoredValue(null)
    setPendingOp(null)
    setWaitingForOperand(false)
    setJustEvaluated(true)
    setRiggedActive(false)
    setNumSequence([])
    setOpSequence([])
  }, [display, storedValue, pendingOp, targetNumber, riggedActive, numSequence, opSequence])

  // ── AC / Clear ───────────────────────────────────────────────────────────
  const handleAC = useCallback(() => {
    setDisplay('0')
    setExpression('')
    setStoredValue(null)
    setPendingOp(null)
    setWaitingForOperand(false)
    setJustEvaluated(false)
    setRiggedActive(false)
    setNumSequence([])
    setOpSequence([])
  }, [])

  const handleBackspace = useCallback(() => {
    if (display.length <= 1) { setDisplay('0'); return }
    setDisplay(display.slice(0, -1))
  }, [display])

  const handlePercent = useCallback(() => {
    setDisplay(String(parseFloat(display) / 100))
  }, [display])

  const handlePlusMinus = useCallback(() => {
    if (display === '0') return
    setDisplay(display.startsWith('-') ? display.slice(1) : '-' + display)
  }, [display])

  // ── Long press % → secret menu ────────────────────────────────────────────
  const startLongPress = () => {
    longPressStarted.current = false
    longPressTimer.current = setTimeout(() => {
      longPressStarted.current = true
      setShowSecret(true)
      setSecretSaved(false)
      if (targetNumber !== null) setSecretInput(String(targetNumber))
      else setSecretInput('')
    }, 5000)
  }

  const endLongPress = () => {
    clearTimeout(longPressTimer.current)
    if (!longPressStarted.current) {
      handlePercent()
    }
    longPressStarted.current = false
  }

  // ── Secret menu actions ───────────────────────────────────────────────────
  const confirmSecret = () => {
    const val = parseFloat(secretInput)
    if (!isNaN(val)) {
      setTargetNumber(val)
      setSecretSaved(true)
      setTimeout(() => setShowSecret(false), 900)
    }
  }

  const clearTarget = () => {
    setTargetNumber(null)
    setSecretInput('')
    setRiggedActive(false)
    setNumSequence([])
    setOpSequence([])
    setShowSecret(false)
  }

  // ── Keyboard support ──────────────────────────────────────────────────────
  useEffect(() => {
    const onKey = (e) => {
      if (showSecret) return
      if ('0123456789'.includes(e.key)) handleDigit(e.key)
      else if (e.key === '.') handleDigit('.')
      else if (e.key === '+') handleOperator('+')
      else if (e.key === '-') handleOperator('−')
      else if (e.key === '*') handleOperator('×')
      else if (e.key === '/') { e.preventDefault(); handleOperator('÷') }
      else if (e.key === 'Enter' || e.key === '=') handleEquals()
      else if (e.key === 'Backspace') handleBackspace()
      else if (e.key === 'Escape') handleAC()
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [handleDigit, handleOperator, handleEquals, handleBackspace, handleAC, showSecret])

  // ── Dynamic font size for display ─────────────────────────────────────────
  const cleanDisplay = display.replace(/[^0-9.]/g, '')
  const displayFontSize = cleanDisplay.length > 11 ? '2.4rem'
    : cleanDisplay.length > 9 ? '2.9rem'
    : display.length > 7 ? '3.8rem'
    : '5rem'

  // ── Button component ──────────────────────────────────────────────────────
  const Btn = ({ id, label, type = 'num', onPress, onPressStart, onPressEnd, wide = false }) => {
    const isActiveOp = type === 'op' && pendingOp === label && waitingForOperand
    const isDown = pressedBtn === id

    let bg, fg
    if (isActiveOp)     { bg = '#ffffff'; fg = '#FF9F0A' }
    else if (type === 'op')  { bg = isDown ? '#ffc966' : '#FF9F0A'; fg = '#ffffff' }
    else if (type === 'fn')  { bg = isDown ? '#d4d4d4' : '#A5A5A5'; fg = '#000000' }
    else                { bg = isDown ? '#737373' : '#333333'; fg = '#ffffff' }

    const handleDown = (e) => {
      e.preventDefault()
      setPressedBtn(id)
      onPressStart?.()
      if (!onPressStart) {
        onPress?.()
      }
    }
    const handleUp = (e) => {
      e.preventDefault()
      setPressedBtn(null)
      onPressEnd?.()
    }

    return (
      <button
        onPointerDown={handleDown}
        onPointerUp={handleUp}
        onPointerLeave={handleUp}
        style={{
          width: wide ? 'calc(50% - 6px)' : 'calc(25% - 9px)',
          aspectRatio: wide ? '2.09 / 1' : '1 / 1',
          borderRadius: '999px',
          background: bg,
          color: fg,
          fontSize: label.length > 2 ? '1.3rem' : '1.85rem',
          fontWeight: '400',
          border: 'none',
          cursor: 'pointer',
          display: 'flex',
          alignItems: 'center',
          justifyContent: wide ? 'flex-start' : 'center',
          paddingLeft: wide ? '1.5rem' : '0',
          userSelect: 'none',
          WebkitUserSelect: 'none',
          touchAction: 'none',
          transition: 'background 0.06s',
          fontFamily: "-apple-system, 'SF Pro Display', 'Helvetica Neue', sans-serif",
          letterSpacing: '-0.01em',
          flexShrink: 0,
          WebkitTapHighlightColor: 'transparent',
        }}
      >
        {label}
      </button>
    )
  }

  // ─────────────────────────────────────────────────────────────────────────
  return (
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'flex-end',
      minHeight: '100svh',
      background: '#000',
      fontFamily: "-apple-system, 'SF Pro Display', 'Helvetica Neue', sans-serif",
      overscrollBehavior: 'none',
      WebkitOverscrollBehavior: 'none',
    }}>
      <div style={{
        width: 'min(390px, 100vw)',
        minHeight: '100svh',
        background: '#000',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'flex-end',
        padding: '0 12px 28px 12px',
        boxSizing: 'border-box',
        position: 'relative',
      }}>

        {/* ── Display area ── */}
        <div style={{
          padding: '0 6px',
          marginBottom: '12px',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'flex-end',
          alignItems: 'flex-end',
          minHeight: '140px',
        }}>
          {/* Scrollable expression / working history */}
          <div
            ref={expressionRef}
            style={{
              color: '#8a8a8a',
              fontSize: '1.15rem',
              letterSpacing: '0.01em',
              marginBottom: '4px',
              maxWidth: '100%',
              overflowX: 'auto',
              overflowY: 'hidden',
              whiteSpace: 'nowrap',
              textAlign: 'right',
              scrollbarWidth: 'none',
              msOverflowStyle: 'none',
              // Fade left edge when scrollable
              WebkitMaskImage: 'linear-gradient(to right, transparent 0%, black 10%)',
              maskImage: 'linear-gradient(to right, transparent 0%, black 10%)',
              minHeight: '1.6rem',
              direction: 'rtl',  // keeps right-aligned and auto-scrolls to newest
            }}
          >
            <span style={{ direction: 'ltr', display: 'inline-block' }}>{expression}</span>
          </div>

          {/* Main number */}
          <div style={{
            color: '#ffffff',
            fontSize: displayFontSize,
            fontWeight: '200',
            letterSpacing: '-0.02em',
            lineHeight: 1,
            textAlign: 'right',
            width: '100%',
            transition: 'font-size 0.08s',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            whiteSpace: 'nowrap',
          }}>
            {display}
          </div>
        </div>

        {/* ── Button grid ── */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>

          {/* Row 1: AC  +/-  %  ÷ */}
          <div style={{ display: 'flex', gap: '10px' }}>
            <Btn id="ac"  label="AC"  type="fn" onPress={handleAC} />
            <Btn id="pm"  label="+/−" type="fn" onPress={handlePlusMinus} />
            <Btn
              id="pct"
              label="%"
              type="fn"
              onPressStart={startLongPress}
              onPressEnd={endLongPress}
            />
            <Btn id="div" label="÷"   type="op" onPress={() => handleOperator('÷')} />
          </div>

          {/* Row 2: 7  8  9  × */}
          <div style={{ display: 'flex', gap: '10px' }}>
            <Btn id="7"   label="7" onPress={() => handleDigit('7')} />
            <Btn id="8"   label="8" onPress={() => handleDigit('8')} />
            <Btn id="9"   label="9" onPress={() => handleDigit('9')} />
            <Btn id="mul" label="×" type="op" onPress={() => handleOperator('×')} />
          </div>

          {/* Row 3: 4  5  6  − */}
          <div style={{ display: 'flex', gap: '10px' }}>
            <Btn id="4"   label="4" onPress={() => handleDigit('4')} />
            <Btn id="5"   label="5" onPress={() => handleDigit('5')} />
            <Btn id="6"   label="6" onPress={() => handleDigit('6')} />
            <Btn id="sub" label="−" type="op" onPress={() => handleOperator('−')} />
          </div>

          {/* Row 4: 1  2  3  + */}
          <div style={{ display: 'flex', gap: '10px' }}>
            <Btn id="1"   label="1" onPress={() => handleDigit('1')} />
            <Btn id="2"   label="2" onPress={() => handleDigit('2')} />
            <Btn id="3"   label="3" onPress={() => handleDigit('3')} />
            <Btn id="add" label="+" type="op" onPress={() => handleOperator('+')} />
          </div>

          {/* Row 5: 0(wide)  .  = */}
          <div style={{ display: 'flex', gap: '10px' }}>
            <Btn id="0"  label="0" wide onPress={() => handleDigit('0')} />
            <Btn id="dot" label="." onPress={() => handleDigit('.')} />
            <Btn id="eq"  label="=" type="op" onPress={handleEquals} />
          </div>
        </div>

        {/* ── Armed indicator (tiny orange dot) ── */}
        {targetNumber !== null && (
          <div style={{
            position: 'absolute',
            top: '20px',
            right: '22px',
            width: '7px',
            height: '7px',
            borderRadius: '50%',
            background: '#FF9F0A',
            opacity: 0.75,
          }} />
        )}

        {/* ── Secret config overlay ── */}
        {showSecret && (
          <div
            onClick={(e) => { if (e.target === e.currentTarget) setShowSecret(false) }}
            style={{
              position: 'fixed',
              inset: 0,
              background: 'rgba(0,0,0,0.88)',
              backdropFilter: 'blur(24px)',
              WebkitBackdropFilter: 'blur(24px)',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '18px',
              zIndex: 200,
              padding: '40px 32px',
              boxSizing: 'border-box',
            }}
          >
            {/* Close */}
            <button
              onClick={() => setShowSecret(false)}
              style={{
                position: 'absolute',
                top: '22px',
                right: '22px',
                background: 'none',
                border: 'none',
                color: '#666',
                fontSize: '2rem',
                lineHeight: 1,
                cursor: 'pointer',
                padding: '4px 10px',
              }}
            >×</button>

            <div style={{ fontSize: '2.2rem', opacity: 0.35 }}>🔒</div>

            <div style={{
              color: '#fff',
              fontSize: '1rem',
              fontWeight: '600',
              letterSpacing: '0.08em',
              textTransform: 'uppercase',
              opacity: 0.75,
            }}>Configuration</div>

            <div style={{
              color: '#666',
              fontSize: '0.72rem',
              letterSpacing: '0.06em',
              textTransform: 'uppercase',
              marginTop: '-8px',
            }}>Target Number</div>

            <input
              type="number"
              inputMode="decimal"
              value={secretInput}
              onChange={(e) => setSecretInput(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') confirmSecret() }}
              placeholder="0"
              autoFocus
              style={{
                width: '100%',
                maxWidth: '320px',
                padding: '16px 20px',
                background: '#1c1c1e',
                border: '1px solid #3a3a3c',
                borderRadius: '14px',
                color: '#fff',
                fontSize: '2rem',
                fontWeight: '200',
                textAlign: 'center',
                outline: 'none',
                letterSpacing: '0.01em',
                fontFamily: "-apple-system, 'SF Pro Display', sans-serif",
                boxSizing: 'border-box',
              }}
            />

            <button
              onClick={confirmSecret}
              style={{
                width: '100%',
                maxWidth: '320px',
                padding: '17px',
                background: secretSaved ? '#30d158' : '#FF9F0A',
                border: 'none',
                borderRadius: '14px',
                color: '#fff',
                fontSize: '1.05rem',
                fontWeight: '600',
                cursor: 'pointer',
                letterSpacing: '0.03em',
                transition: 'background 0.25s',
                fontFamily: "-apple-system, 'SF Pro Display', sans-serif",
              }}
            >
              {secretSaved ? '✓  Saved' : 'Set Target'}
            </button>

            {targetNumber !== null && !secretSaved && (
              <>
                <div style={{ color: '#555', fontSize: '0.78rem', marginTop: '-6px' }}>
                  Active target: {targetNumber.toLocaleString('en-US')}
                </div>
                <button
                  onClick={clearTarget}
                  style={{
                    background: 'none',
                    border: 'none',
                    color: '#ff453a',
                    fontSize: '0.92rem',
                    cursor: 'pointer',
                    letterSpacing: '0.02em',
                    fontFamily: "-apple-system, 'SF Pro Display', sans-serif",
                  }}
                >
                  Clear Target
                </button>
              </>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
