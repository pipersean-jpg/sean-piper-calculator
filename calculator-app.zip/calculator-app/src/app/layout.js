import './globals.css'
export const metadata = {
  title: 'Calculator',
  description: 'Calculator',
  viewport: 'width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no',
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
        <meta name="theme-color" content="#000000" />
        <link rel="apple-touch-icon" href="/icon.png" />
      </head>
      <body style={{ margin: 0, padding: 0, background: '#000', overscrollBehavior: 'none' }}>
        {children}
      </body>
    </html>
  )
}
